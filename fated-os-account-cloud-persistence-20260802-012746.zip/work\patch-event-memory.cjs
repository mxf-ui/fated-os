﻿const fs = require('fs');
const path = require('path');
const root = process.cwd();
function p(file){ return path.join(root, file); }
function edit(file, fn){
  const fp = p(file);
  const before = fs.readFileSync(fp, 'utf8');
  const after = fn(before);
  if(after === before) throw new Error('No change in ' + file);
  fs.writeFileSync(fp, after, 'utf8');
  console.log('patched', file);
}
function once(file, from, to){
  edit(file, s => {
    if(s.includes(to)) return s;
    if(!s.includes(from)) throw new Error('Pattern not found in '+file+': '+from.slice(0,100));
    return s.replace(from, to);
  });
}
function rx(file, pattern, replacer){
  edit(file, s => {
    if(typeof replacer === 'string' && s.includes(replacer)) return s;
    const after = s.replace(pattern, replacer);
    return after;
  });
}

rx('index.html', /<script src="js\/main\/core\/08-cloud-sync\.js"><\/script>\s*<script src="js\/main\/04-moments-social\.js"><\/script>/, '<script src="js/main/core/08-cloud-sync.js"></script>\n\n<script src="js/main/core/10-event-memory.js"></script>\n\n<script src="js/main/04-moments-social.js"></script>');

rx('js/main/core/05-persistence.js', /nilflow: typeof nilflowState!=='undefined' && nilflowState \? nilflowState : null\s*\};/, "nilflow: typeof nilflowState!=='undefined' && nilflowState ? nilflowState : null,\n    fatedEventState: typeof fatedEventState!=='undefined' && fatedEventState ? fatedEventState : null\n  };");
rx('js/main/core/05-persistence.js', /if\(s\.nilflow && typeof s\.nilflow==='object'\)\{ nilflowState=Object\.assign\(nilflowDefault\(\), s\.nilflow\); if\(typeof nilflowEnsureStateShape==='function'\) nilflowEnsureStateShape\(\); \}\s*\n\s*if\(s\.userCover!==undefined\) userCover=s\.userCover;/, "if(s.nilflow && typeof s.nilflow==='object'){ nilflowState=Object.assign(nilflowDefault(), s.nilflow); if(typeof nilflowEnsureStateShape==='function') nilflowEnsureStateShape(); }\n  if(s.fatedEventState && typeof s.fatedEventState==='object'){ fatedEventState=s.fatedEventState; if(typeof fatedEnsureEventState==='function') fatedEnsureEventState(); }\n\n  if(s.userCover!==undefined) userCover=s.userCover;");
rx('js/main/core/05-persistence.js', /if\(changed\) repaintPersistentAssets\(\);\s*\n\s*cb&&cb\(changed\);/, "fatedDBLoadKV('fated_event_state', function(evState){\n                    if(evState && typeof evState==='object'){ fatedEventState=evState; if(typeof fatedEnsureEventState==='function') fatedEnsureEventState(); changed=true; }\n                    if(changed) repaintPersistentAssets();\n                    cb&&cb(changed);\n                  });");

edit('js/main/chat/ai/03-context-prompt-search.js', s => {
  if(s.includes('fatedGlobalContextPrompt(contactId, {limit:16})')) return s;
  return s.replace(/function buildContextAddons\(contactId\)\{[\s\S]*?return s;\s*\}/, block => block.replace(/\s*return s;/, "\n  if(typeof fatedGlobalContextPrompt==='function'){\n    var globalCtx = fatedGlobalContextPrompt(contactId, {limit:16});\n    if(globalCtx) s += '\\n\\n' + globalCtx;\n  }\n  return s;"));
});

once('js/main/01-system-shell.js', "  if(coupleCheckAppLocked(id, opts)) return false;\n  fatedCloseDesktopAppSurfaces(id);", "  if(coupleCheckAppLocked(id, opts)) return false;\n  if(typeof fatedLogEvent==='function') fatedLogEvent('app.open', {app:id, title:a.name || id, actor:'user'}, {app:id});\n  fatedCloseDesktopAppSurfaces(id);");

once('js/main/chat/ai/05-user-message-actions.js', "  c.seed.push({mine:true, kind:'text', text, from:'me', ts:nowStamp()});", "  c.seed.push({mine:true, kind:'text', text, from:'me', ts:nowStamp()});\n\n  if(typeof fatedLogEvent==='function') fatedLogEvent('wechat.message.user', {app:'wechat', contactId:currentContact, actor:'user', text:text});");
once('js/main/chat/ai/05-user-message-actions.js', "  c.seed.push({mine:true, kind:'voice', dur, from:'me', ts:nowStamp()});", "  c.seed.push({mine:true, kind:'voice', dur, from:'me', ts:nowStamp()});\n\n  if(typeof fatedLogEvent==='function') fatedLogEvent('wechat.message.user.voice', {app:'wechat', contactId:currentContact, actor:'user', text:'voice message'});");

once('js/main/chat/ai/02-real-ai-reply.js', "        chatTarget.seed.push({mine:false, kind:'text', text:reply, from:id, ts:nowStamp()});", "        chatTarget.seed.push({mine:false, kind:'text', text:reply, from:id, ts:nowStamp()});\n        if(typeof fatedLogEvent==='function') fatedLogEvent('wechat.message.contact', {app:'wechat', contactId:id, actor:(typeof fatedEventContactName==='function' ? fatedEventContactName(id) : id), text:reply});");
