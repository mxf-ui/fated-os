﻿const fs = require('fs');
const path = require('path');
const root = process.cwd();
function p(file){ return path.join(root, file); }
function edit(file, fn){
  const fp = p(file);
  const before = fs.readFileSync(fp, 'utf8');
  const after = fn(before);
  if(after === before) throw new Error('No change in ' + file);
  fs.writeFileSync(fp, after, 'utf8');
  console.log('patched', file);
}
function once(file, from, to){
  edit(file, s => {
    if(s.includes(to)) return s;
    if(!s.includes(from)) throw new Error('Pattern not found in '+file+': '+from.slice(0,100));
    return s.replace(from, to);
  });
}

once('js/couple/02-diary-notes-location.js', "    d.diary.push(entry);\n    window.saveCoupleState();", "    d.diary.push(entry);\n    if(typeof fatedLogEvent==='function') fatedLogEvent('couple.diary.add', {app:'couple', contactId:coupleState.partner, actor:'user', text:v});\n    window.saveCoupleState();");
once('js/couple/02-diary-notes-location.js', "      d.diaryReplies.push({entryId:entry.id, text:reply.trim(), ts:Date.now(), partnerId:coupleState.partner});\n      d.diaryFeelings.push({entryId:entry.id, text:feeling.trim(), ts:Date.now(), partnerId:coupleState.partner});", "      d.diaryReplies.push({entryId:entry.id, text:reply.trim(), ts:Date.now(), partnerId:coupleState.partner});\n      d.diaryFeelings.push({entryId:entry.id, text:feeling.trim(), ts:Date.now(), partnerId:coupleState.partner});\n      if(typeof fatedLogEvent==='function') fatedLogEvent('couple.diary.partner_reply', {app:'couple', contactId:coupleState.partner, actor:partnerName(), text:reply.trim()+' / '+feeling.trim()});");
once('js/couple/02-diary-notes-location.js', "    d.notes.push({id:'note-' + Date.now(), date:ymdKey(new Date()), text:v, source:'user', ts:Date.now()});\n    window.saveCoupleState();", "    d.notes.push({id:'note-' + Date.now(), date:ymdKey(new Date()), text:v, source:'user', ts:Date.now()});\n    if(typeof fatedLogEvent==='function') fatedLogEvent('couple.note.add', {app:'couple', contactId:coupleState.partner, actor:'user', text:v});\n    window.saveCoupleState();");
once('js/couple/02-diary-notes-location.js', "  window.coupleSetLoc = function(lat,lng){ var d=window.coupleData(); d.location={lat:lat,lng:lng,ts:Date.now()}; window.saveCoupleState(); window.renderLocationView(lat,lng); };", "  window.coupleSetLoc = function(lat,lng){ var d=window.coupleData(); d.location={lat:lat,lng:lng,ts:Date.now()}; if(typeof fatedLogEvent==='function') fatedLogEvent('couple.location.set', {app:'couple', contactId:coupleState.partner, actor:'user', text:'lat '+Number(lat).toFixed(4)+', lng '+Number(lng).toFixed(4)}); window.saveCoupleState(); window.renderLocationView(lat,lng); };");
once('js/couple/02-diary-notes-location.js', "    showToast('\\u5df2\\u5206\\u4eab\\u4f4d\\u7f6e', 1600);", "    if(typeof fatedLogEvent==='function') fatedLogEvent('couple.location.share', {app:'couple', contactId:coupleState.partner, actor:'user', text:'shared location'});\n    showToast('\\u5df2\\u5206\\u4eab\\u4f4d\\u7f6e', 1600);");

once('js/couple/03-shop-food.js', "    d.partnerWishlist.splice(i,1);\n    d.shop = d.partnerWishlist;", "    if(typeof fatedLogEvent==='function') fatedLogEvent('couple.shop.buy_partner', {app:'couple', contactId:coupleState.partner, actor:'user', title:item.name, text:item.price+' '+(item.reason||'')});\n    d.partnerWishlist.splice(i,1);\n    d.shop = d.partnerWishlist;");
once('js/couple/03-shop-food.js', "    d.myShop.push({id:'my-shop-' + Date.now(), name:name, price:price, img:coupleState._shopImg || '', owner:'self', ts:Date.now()});", "    d.myShop.push({id:'my-shop-' + Date.now(), name:name, price:price, img:coupleState._shopImg || '', owner:'self', ts:Date.now()});\n    if(typeof fatedLogEvent==='function') fatedLogEvent('couple.shop.add_self', {app:'couple', contactId:coupleState.partner, actor:'user', title:name, text:price});");
once('js/couple/03-shop-food.js', "    if(target === 'self') d.selfFoodOrders.push(order); else d.partnerFoodOrders.push(order);\n    d.foodOrders.push(order);", "    if(target === 'self') d.selfFoodOrders.push(order); else d.partnerFoodOrders.push(order);\n    d.foodOrders.push(order);\n    if(typeof fatedLogEvent==='function') fatedLogEvent('couple.food.order', {app:'couple', contactId:coupleState.partner, actor:'user', target:target, title:name, text:price+(note?(' / '+note):'')});");

edit('js/dream/00-dreamcore.js', s => {
  if(s.includes("fatedGlobalContextPrompt(id, {limit:18})")) return s;
  s = s.replace("    dreamBuildRelationshipMemoryPrompt(run),\n    dreamBuildRunLogPrompt(run),", "    dreamBuildRelationshipMemoryPrompt(run),\n    (typeof fatedGlobalContextPrompt==='function' ? fatedGlobalContextPrompt(id, {limit:18}) : ''),\n    dreamBuildRunLogPrompt(run),");
  s = s.replace("    dreamBuildRelationshipMemoryPrompt(run),\n    dreamBuildRunLogPrompt(run),\n    '[Narrator rules]'", "    dreamBuildRelationshipMemoryPrompt(run),\n    (typeof fatedGlobalContextPrompt==='function' ? fatedGlobalContextPrompt(null, {limit:18}) : ''),\n    dreamBuildRunLogPrompt(run),\n    '[Narrator rules]'");
  return s;
});
once('js/dream/00-dreamcore.js', "  run.messages.push(msg);\n  dreamAppendDreamMemory(run, msg.role === 'contact' ? msg.contactId : msg.role, msg.text || '');", "  run.messages.push(msg);\n  dreamAppendDreamMemory(run, msg.role === 'contact' ? msg.contactId : msg.role, msg.text || '');\n  if(typeof fatedLogEvent==='function') fatedLogEvent('dream.message.'+(msg.role || 'unknown'), {app:'dream', contactId:msg.contactId || '', actor:msg.role || '', text:msg.text || ''});");
once('js/dream/00-dreamcore.js', "  dreamState.run = {id:'dream-'+Date.now().toString(36), startedAt:Date.now(),", "  if(typeof fatedLogEvent==='function') fatedLogEvent('dream.run.start', {app:'dream', actor:'user', title:cfg.name || 'Dreamcore run', text:mainTask, meta:{contacts:enabled}});\n  dreamState.run = {id:'dream-'+Date.now().toString(36), startedAt:Date.now(),");
once('js/dream/00-dreamcore.js', "  run.usedCards.push(card.title);", "  run.usedCards.push(card.title);\n  if(typeof fatedLogEvent==='function') fatedLogEvent('dream.card.choose', {app:'dream', actor:'user', title:card.title, text:(card.effect || '')+' / '+(card.risk || '')});");
once('js/dream/00-dreamcore.js', "  run.completedAt = Date.now();\n  dreamPushMessage(run, {role:'system', text:'\\u526f\\u672c\\u7ed3\\u7b97\\uff1a'+rank+' / '+reward.name, at:Date.now()});", "  run.completedAt = Date.now();\n  if(typeof fatedLogEvent==='function') fatedLogEvent('dream.run.complete', {app:'dream', actor:'system', title:rank, text:reward.name, meta:{score:score}});\n  dreamPushMessage(run, {role:'system', text:'\\u526f\\u672c\\u7ed3\\u7b97\\uff1a'+rank+' / '+reward.name, at:Date.now()});");

edit('js/nilflow/00-nilflow.js', s => {
  if(s.includes("fatedGlobalContextPrompt(null, {limit:14})")) return s;
  return s.replace("    '\\u8fd9\\u6b21\\u8981\\u6839\\u636e\\u4eba\\u8bbe\\u3001\\u4e16\\u754c\\u89c2\\u3001\\u5173\\u7cfb\\u9636\\u6bb5\\u548c\\u804a\\u5929\\u5386\\u53f2\\u56de\\u5e94\\uff0c\\u4e0d\\u8981\\u6a21\\u677f\\u5316\\uff0c\\u4e0d\\u8981\\u50cf\\u5ba2\\u670d\\u3002'", "    '\\u8fd9\\u6b21\\u8981\\u6839\\u636e\\u4eba\\u8bbe\\u3001\\u4e16\\u754c\\u89c2\\u3001\\u5173\\u7cfb\\u9636\\u6bb5\\u548c\\u804a\\u5929\\u5386\\u53f2\\u56de\\u5e94\\uff0c\\u4e0d\\u8981\\u6a21\\u677f\\u5316\\uff0c\\u4e0d\\u8981\\u50cf\\u5ba2\\u670d\\u3002',\n    (typeof fatedGlobalContextPrompt==='function' ? fatedGlobalContextPrompt(null, {limit:14}) : '')");
});
once('js/nilflow/00-nilflow.js', "  p.likes=p.likedBy.length;\n  nilflowSave();", "  p.likes=p.likedBy.length;\n  if(typeof fatedLogEvent==='function') fatedLogEvent(idx>=0?'nilflow.post.unlike':'nilflow.post.like', {app:'nilflow', actor:me, title:p.author, text:p.text});\n  nilflowSave();");
once('js/nilflow/00-nilflow.js', "  p.commentList.push({id:nilflowId(), author:nilflowState.profile.id.trim(), text:text, ts:Date.now()});", "  p.commentList.push({id:nilflowId(), author:nilflowState.profile.id.trim(), text:text, ts:Date.now()});\n  if(typeof fatedLogEvent==='function') fatedLogEvent('nilflow.post.comment', {app:'nilflow', actor:nilflowState.profile.id.trim(), title:p.author, text:text});");
once('js/nilflow/00-nilflow.js', "  nilflowState.history.push({id:id, action:'宸查€氳繃骞惰В閿佺鑱?, ts:Date.now()});", "  nilflowState.history.push({id:id, action:'宸查€氳繃骞惰В閿佺鑱?, ts:Date.now()});\n  if(typeof fatedLogEvent==='function') fatedLogEvent('nilflow.match.accept', {app:'nilflow', actor:nilflowState.profile.id || 'guest', title:id, text:'matched anonymous user'});");
once('js/nilflow/00-nilflow.js', "  list.push({from:'me', text:text, ts:Date.now()});", "  list.push({from:'me', text:text, ts:Date.now()});\n  if(typeof fatedLogEvent==='function') fatedLogEvent('nilflow.message.user', {app:'nilflow', actor:nilflowState.profile.id || 'guest', title:id, text:text});");
once('js/nilflow/00-nilflow.js', "      next.push({from:'them', text:reply, ts:Date.now()});", "      next.push({from:'them', text:reply, ts:Date.now()});\n      if(typeof fatedLogEvent==='function') fatedLogEvent('nilflow.message.reply', {app:'nilflow', actor:id, title:id, text:reply});");
once('js/nilflow/00-nilflow.js', "  nilflowState.posts.unshift(post);", "  nilflowState.posts.unshift(post);\n  if(typeof fatedLogEvent==='function') fatedLogEvent('nilflow.post.create', {app:'nilflow', actor:nilflowState.profile.id.trim(), title:post.style, text:text});");
