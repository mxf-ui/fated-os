﻿const fs = require('fs');
const file = 'tools/verify-dreamcore-app.mjs';
let text = fs.readFileSync(file, 'utf8');
if(!text.includes("'.dream-run-page'")) throw new Error('verify script unexpected');
if(!text.includes('Dreamcore scroll fix')){
  text = text.replace("if (!dream.includes(\"['S+','S','A','B','C']\")) fail('Dream scoring must use the required ranks.');", "if (!dream.includes(\"['S+','S','A','B','C']\")) fail('Dream scoring must use the required ranks.');\nif (!css.includes('Dreamcore scroll fix')) fail('Dream sheet must include the scroll fix guard.');\nif (!css.includes('#sheet-dream .dream-body{ flex:1 1 auto; min-height:0;')) fail('Dream setup view must be vertically scrollable.');\nif (!css.includes('#sheet-dream .dream-run-page{ min-height:0; height:100%; overflow-y:auto;')) fail('Dream run view must be vertically scrollable.');");
  fs.writeFileSync(file, text, 'utf8');
}
