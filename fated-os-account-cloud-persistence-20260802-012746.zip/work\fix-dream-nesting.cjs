﻿const fs = require('fs');
const file = 'index.html';
let html = fs.readFileSync(file, 'utf8');
const before = '        </div>\n      <div class="dream-save-burst" id="dream-save-burst"></div>';
const after = '        </div>\n      </div>\n      <div class="dream-save-burst" id="dream-save-burst"></div>';
if(!html.includes(before)) throw new Error('target nesting sequence not found');
html = html.replace(before, after);
fs.writeFileSync(file, html, 'utf8');
